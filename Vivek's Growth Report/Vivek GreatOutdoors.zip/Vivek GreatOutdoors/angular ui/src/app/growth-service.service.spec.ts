import { TestBed } from '@angular/core/testing';

import { GrowthServiceService } from './growth-service.service';

describe('GrowthServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GrowthServiceService = TestBed.get(GrowthServiceService);
    expect(service).toBeTruthy();
  });
});
