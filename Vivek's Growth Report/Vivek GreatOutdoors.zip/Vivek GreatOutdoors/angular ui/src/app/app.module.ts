import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';

import { GrowthtableComponent } from './growthtable/growthtable.component';

const appRoutes:Routes=[
  
  {path:'growthReportTable',component:GrowthtableComponent},
  

  {path:'**',redirectTo:'',pathMatch:'full'}
]

@NgModule({
  declarations: [
    AppComponent,
     
     GrowthtableComponent,
    
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  
  bootstrap: [AppComponent]
})
export class AppModule { }
