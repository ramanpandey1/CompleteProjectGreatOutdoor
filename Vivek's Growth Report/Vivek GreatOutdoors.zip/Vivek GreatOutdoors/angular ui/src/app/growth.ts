export class Growth {
    userId:number;
    period:string;
    revenue:number;
    amountChange:number;
    percentageGrowth:number;
    colrCode:string;
    
}
