import { Component, OnInit } from '@angular/core';
import {GrowthServiceService} from '../growth-service.service';
import { Growth } from '../growth';

@Component({
  selector: 'app-growthtable',
  templateUrl: './growthtable.component.html',
  styleUrls: ['./growthtable.component.css']
})
export class GrowthtableComponent implements OnInit {

  constructor(private growthservice:GrowthServiceService) { }
  growth:Growth[]=[];


  ngOnInit(): void {
    this.growthservice.loaddate().subscribe(data=>
      {this.growth=data;
    },
    error=>
    {
      console.log("error occured in growth table",error);
    }
      );
  }
}