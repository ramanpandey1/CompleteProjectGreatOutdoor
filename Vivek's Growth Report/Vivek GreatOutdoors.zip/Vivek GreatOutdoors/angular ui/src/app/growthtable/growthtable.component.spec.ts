import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GrowthtableComponent } from './growthtable.component';

describe('GrowthtableComponent', () => {
  let component: GrowthtableComponent;
  let fixture: ComponentFixture<GrowthtableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GrowthtableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GrowthtableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
