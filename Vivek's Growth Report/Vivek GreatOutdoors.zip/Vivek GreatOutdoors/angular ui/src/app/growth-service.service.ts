import { Injectable } from '@angular/core';
import { Growth } from './growth';
import {HttpClient, HttpClientModule} from '@angular/common/http'
import {Observable} from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class GrowthServiceService {
  growth:Growth[]=[];

  constructor(private http:HttpClient) { }

  loaddate():Observable<any>
  {
    let url = "http://localhost:1114/growthReportTable";

    return this.http.get(url);
  }

  

}
