export class Product{
    productId:number;
    productName:string;
    productBrand:string;
    productCategory:number;
    productQuantity:number;
    productDimension:string;
    productSpecification:string;
    productColour:string;
    productPrice:number;
    productManufacturer:string;

}