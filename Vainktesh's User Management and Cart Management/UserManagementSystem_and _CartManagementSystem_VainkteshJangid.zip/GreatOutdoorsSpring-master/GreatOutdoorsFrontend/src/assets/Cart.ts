export class Cart{
    productId:number;
    userId:number;
    quantity:number;
}