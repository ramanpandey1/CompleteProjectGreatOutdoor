package com.cg.greatoutdoors.entity;

import java.io.Serializable;

public class CartCompositePK implements Serializable{
	public Long productId;
	
	public Long userId;

	public CartCompositePK() {
		super();
	}

	public CartCompositePK(Long productId, Long userId) {
		super();
		this.productId = productId;
		this.userId = userId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((productId == null) ? 0 : productId.hashCode());
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CartCompositePK other = (CartCompositePK) obj;
		if (productId == null) {
			if (other.productId != null)
				return false;
		} else if (!productId.equals(other.productId))
			return false;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		return true;
	}
	
	
	
	

}
