package com.cg.greatoutdoors.dao;

public interface IAddressDao {

	public void create();
}
