package com.cg.greatoutdoors.exception;

public class AlreadyPresentInCartException extends Exception {
	public AlreadyPresentInCartException(String msg) {
		super(msg);
	}

}
