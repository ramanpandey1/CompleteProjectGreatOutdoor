package com.cg.greatoutdoors.exception;

public class UsernameAlreadyTakenException extends Exception {
	public UsernameAlreadyTakenException(String msg) {
		super(msg);
	}
}
