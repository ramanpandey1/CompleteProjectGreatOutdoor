package com.cg.greatoutdoors.dao;

public class AddressDaoImpl implements IAddressDao{

	@Override
	public void create() {
		// TODO Auto-generated method stub
		
	}

}
