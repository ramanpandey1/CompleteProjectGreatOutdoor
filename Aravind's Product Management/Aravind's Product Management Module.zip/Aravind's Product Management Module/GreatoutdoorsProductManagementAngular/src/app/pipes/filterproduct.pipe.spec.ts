import { FilterproductPipe } from './filterproduct.pipe';

describe('FilterproductPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterproductPipe();
    expect(pipe).toBeTruthy();
  });
});
