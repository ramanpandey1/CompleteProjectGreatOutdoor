export class UserDTO {
    userId: number;
    userName: string;
    userPassword: string;
    userPhoneNumber: string;
    userEmail: string;
    userRole: number;

}