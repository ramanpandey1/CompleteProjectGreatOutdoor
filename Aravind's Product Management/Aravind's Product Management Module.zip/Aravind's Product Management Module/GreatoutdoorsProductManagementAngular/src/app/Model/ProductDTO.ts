export class ProductDTO
{
    productId:number;
    productName:string;
    productBrand:string;
    productCategory:string;
    productQuantity:number;
    productDimension:string;
    productSpecification:string;
    productColour:string;
    productPrice:number;
    productManufacturer:string;

    


}