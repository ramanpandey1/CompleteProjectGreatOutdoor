package com.cpg.go;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class GreatoutdoorProductManagementSpring2Application {

	public static void main(String[] args) {
		SpringApplication.run(GreatoutdoorProductManagementSpring2Application.class, args);
	}

}
