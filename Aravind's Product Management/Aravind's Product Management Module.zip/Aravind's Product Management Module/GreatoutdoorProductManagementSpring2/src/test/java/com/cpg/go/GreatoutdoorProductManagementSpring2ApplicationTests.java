package com.cpg.go;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreatoutdoorProductManagementSpring2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
