package com.cg.exceptions;

public class AddressNotFoundException extends Throwable {
	public AddressNotFoundException(String s)
	{
		super(s);
	}

}
